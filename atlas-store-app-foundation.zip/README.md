# ATLAS STORE — IMPORT & PROFIT

Sistema privado de gestão financeira e operacional da Atlas Store (importação e venda de roupas, tênis e acessórios).

Identidade visual: preto `#000000`, amarelo `#FFD400`, branco `#FFFFFF` · Space Grotesk (display) + Inter (corpo) · dark, premium, streetwear, mobile-first.

## Stack

- **Next.js (App Router)** + TypeScript + Tailwind CSS 4
- **PostgreSQL** via **Drizzle ORM** (`src/db/schema.ts`)
- Server Actions para todas as mutações (cálculos financeiros no servidor)

## Estrutura

```
src/
├── app/
│   ├── page.tsx                  # Dashboard (dados reais do banco)
│   ├── imports/                  # 📦 Importações (lista, nova, detalhes, editar)
│   ├── uscloser/ · cssbuy/       # Calculadoras independentes
│   ├── comparar/                 # USCloser vs CSSBuy
│   ├── quanto-cobrar/            # Calculadora reversa
│   ├── simulador/                # Simulador de negócio
│   ├── produtos/ · vendas/ · metas/ · financeiro/ · historico/ · configuracoes/
│   └── actions/                  # Server Actions (regras de negócio)
├── components/ (layout, ui: toast, confirm-dialog, skeleton)
├── features/                     # Módulos: dashboard, importacoes, uscloser, cssbuy,
│                                 # comparar, produtos, vendas, metas, financeiro,
│                                 # historico, configuracoes, simulador, reverse-calculator
├── db/                           # Schema Drizzle + client
└── lib/                          # format, utils, auth, database
```

## Aba Importações

### Funcionalidades

- **Dashboard da aba**: total de importações, em andamento, valor importado (BRL) e produtos importados — tudo do banco.
- **Criação/edição** (`/imports/new`, `/imports/:id/editar`): nome, método (🇺🇸 US Closer / 🇨🇳 CSSBuy), origem→destino, data, status inicial, fornecedor, observações.
- **Câmbio congelado**: a cotação usada é salva na importação; mudanças futuras nas configurações **não** recalculam importações antigas.
- **Moedas separadas**: produtos/frete/taxas/seguro na moeda do método (USD ou CNY); impostos e outros custos em BRL. Resumo final convertido para BRL.
- **Múltiplos produtos** por importação (selecionar existente ou criar novo sem duplicar), com quantidade, preço unitário, peso e total.
- **Rateio de custos compartilhados** (frete, taxas, seguro, impostos, outros) proporcional ao valor dos produtos → custo final e **custo por unidade** de cada produto.
- **Status com fluxo completo**: 📝 Orçamento → 💳 Aguardando pagamento → 🛒 Comprado → 📦 Preparando envio → 🚚 Enviado → ✈️ Em trânsito → 🇧🇷 Chegou ao Brasil → 📋 Em desembaraço → 📥 Recebido → ✅ Finalizado (e ❌ Cancelado).
- **Timeline** (`importation_events`): criação, mudanças de status, edição e entrada no estoque com datas.
- **Entrada no estoque** com proteção anti-duplicidade (`stock_added` + `stock_movements`): soma quantidade e atualiza o custo médio ponderado do produto; segunda tentativa é bloqueada com “✓ Estoque atualizado”.
- **Exclusão segura**: importações com movimentação de estoque são **arquivadas** (preservando histórico); as demais são excluídas após confirmação.
- **Ações por registro**: visualizar, editar, duplicar, alterar status, excluir, adicionar ao estoque.
- **Filtros e busca**: status, método, moeda, período, marca + busca por nome/fornecedor/produto. **Ordenação**: recente, antiga, maior/menor custo, quantidade, status.
- **Integração com calculadoras**: botão “Salvar como importação” nas calculadoras USCloser e CSSBuy cria a importação com método, moeda, câmbio, custos, impostos e produto vinculado — sem redigitar nada.
- **Responsivo**: tabela no desktop, cards no mobile; formulário confortável no iPhone.

### Banco de dados (reutilizado, sem duplicação)

Tabelas existentes aproveitadas e estendidas:

- `importations` (+ `name`, `other_costs`, `stock_added`, `archived`, `import_date`; enum de status estendido)
- `importation_items` (+ `unit_weight`)

Tabelas novas (não existiam):

- `importation_events` — timeline/histórico da importação
- `stock_movements` — movimentações de estoque por importação

Relacionamentos: Importação → Itens → Produtos · Importação → Eventos · Importação → Movimentações de estoque. Valores monetários sempre `NUMERIC/DECIMAL`.

### Fluxo principal

Nova importação → método → produtos → custos → câmbio → custo final + rateio → salvar → acompanhar status → receber → adicionar ao estoque.

## Regras financeiras (inalteradas)

- Venda: lucro = receita − custo − taxa de pagamento − outros custos; divisão configurável disponível/reinvestimento (padrão 50/50); prejuízo nunca gera “lucro disponível”.
- Metas progridem apenas com o **lucro disponível** das vendas vinculadas.
- Calculadoras com alíquotas 100% configuráveis em Configurações; resultados sempre marcados como estimativa.

## Próximo passo do projeto

- Módulo de despesas completo (alimentando o Financeiro).
- Autenticação privada.
- Anexos/comprovantes nas importações.
